package ca.gbc.microserviceparent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroserviceParentApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroserviceParentApplication.class, args);
	}

}
