package ca.gbc.microserviceparent;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroserviceParentApplicationTests {

	@Test
	void contextLoads() {
	}

}
